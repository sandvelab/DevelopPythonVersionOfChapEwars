import numpy as np
import pytest

from pylgm.effects.directed_graph import normalize_directed_graph, row_standardize
from pylgm.effects.sdpd_forecast import sdpd_forecast


def _w(n):
    graph = {str(i): [str((i + 1) % n)] for i in range(n)}
    _, w = normalize_directed_graph(graph)
    return row_standardize(w)


def test_one_step_mean_matches_closed_form():
    n, rho, gamma, eta, tau = 5, 0.4, 0.3, 0.1, 2.0
    w = _w(n)
    x_last = np.arange(n, dtype=float)
    v_last = np.ones(n)
    a = np.eye(n) - rho * w.toarray()
    b = gamma * np.eye(n) + eta * w.toarray()
    expected_mean = np.linalg.solve(a, b @ x_last)
    (mean, var), = sdpd_forecast(x_last, v_last, rho, gamma, eta, tau, [w])
    assert np.allclose(mean, expected_mean)
    assert np.all(var > 0)


def test_multi_step_iterates():
    n = 4
    w = _w(n)
    steps = sdpd_forecast(np.ones(n), np.ones(n), 0.3, 0.5, 0.0, 1.0, [w, w, w])
    assert len(steps) == 3
    for mean, var in steps:
        assert mean.shape == (n,)
        assert np.all(np.isfinite(mean))
        assert np.all(var > 0)


def test_future_times_sort_numerically():
    from pylgm.effects.directed_graph import sorted_time_keys

    assert sorted_time_keys({"9": 0, "10": 0, "2": 0}) == ("2", "9", "10")
    assert sorted_time_keys({"2021": 0, "2020": 0}) == ("2020", "2021")
    assert sorted_time_keys({"b": 0, "a": 0}) == ("a", "b")  # non-numeric falls back


def test_graphs_by_label_rejects_colliding_period_keys():
    """Two keys with the same str() would silently drop a period's network."""
    from pylgm.effects.directed_graph import graphs_by_label

    assert graphs_by_label({1: "a", 2: "b"}) == {"1": "a", "2": "b"}
    with pytest.raises(ValueError, match="stringify"):
        graphs_by_label({1: "a", "1": "b"})
